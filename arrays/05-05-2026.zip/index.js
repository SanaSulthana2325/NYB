//ARRAY
//
var arr=["1",2,3,4]
console.log(arr)
// in another if we want to add anything for there are 

//some methods of array

//1. push(add items at the end)
// like (if we add function to it)
function Hai(){
arr.push(5)

}
Hai()
console.log(arr)
//
arr.push(6)
console.log(arr)
//
arr.push(7)
console.log(arr)
//
arr.push(90)
console.log(arr)

//2.Unshift()[first]
arr.unshift(8)
console.log(arr)

//
arr.unshift(80)
console.log(arr)

//3.splice()  / we can addit any where
arr.splice(3,2,"hello")
console.log(arr)

var a=[1,2,3,4,5]

console.log(a[0])
console.log(a[3])
// referenceofthearray[0] [1] [2] [3]....n-1

 //4.pop()[remove last item]
 arr.pop()
 console.log(arr)

 //
 arr.pop()
 console.log(arr)

 //5.shift() [removes first item]

 arr.shift()
console.log(arr)

//
arr.shift()
console.log(arr)


//6.splice()
arr.splice(1,1)
console.log(arr)


//Task:
//  add splice at first
let arra= [2,3,4,5,6] 
arra.splice(0,0,1)
console.log(arra)

// add splice at last
arra.splice(arra.length,0,7)
console.log(arra)

//remove first
arra.splice(0,1)
console.log(arra)

// remove last
arra.splice(-1,1)
console.log(arra)

//add the text in middle
arra.splice(1,1,"hai")
console.log(arra)

//
arra.splice(2,1,"sana")
console.log(arra)

//delect or remove text from the middle
arra.splice(2,1)
console.log(arra)

//example

let ARR =["a","b","c","d"]

console.log(ARR.length)

console.log(ARR)

console.log(ARR)

console.log(ARR[4])

//array.length=total items count,starts from 1
// but index starts from 0,so last item= array[array.length-1]
